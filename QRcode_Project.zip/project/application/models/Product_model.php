<?php 
class Product_model extends CI_Model {

        public function get_category_1()
        {
                $query = $this->db->get('category1');
                return $query->result();
        }

        public function get_category_2($parent)
        {
                $query = $this->db->get_where('category2', array('parent' => $parent));
                return $query->result();
        }

        public function get_product($id)
        {
                $query = $this->db->get_where('product_in', array('id' => $id));
                return $query->result();
        }

        public function remain_product()
        {
                $query = $this->db->query("SELECT p.id, p.name, p.amount - COALESCE(o.output_count, 0) AS remaining_amount,  o.last_out_date FROM  product_in p LEFT JOIN  (SELECT  	product_id,  	COUNT(*) as output_count, 	MAX(out_date) as last_out_date FROM product_out  GROUP BY product_id) o ON p.id = o.product_id  ORDER BY  p.id; ");
                return $query->result();
        }

} 
?>