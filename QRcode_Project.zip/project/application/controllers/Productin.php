<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Productin extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	public function index()
	{
		// var_dump($category1[0]->name);
		$this->load->view('product_in');
	}

	public function get_category_1()
	{
		$category1 = $this->product_model->get_category_1();
		echo(json_encode($category1));
	}

	public function get_category_2()
	{
		$id = $_GET['id'];
		$category2 = $this->product_model->get_category_2($id);
		echo(json_encode($category2));
	}

	public function product_in()
	{

		$data = array(
	        'parent' => $_POST['parent'],
	        'name' => $_POST['name'],
	        'amount' => $_POST['amount'],
	        'price' => $_POST['price'],
			'in_date' => time()
		);
		var_dump($data);
		$inserted = $this->db->insert('product_in', $data);
		 if ($inserted) {
	        $new_id = $this->db->insert_id();
	        echo json_encode(array('status' => 'success', 'id' => $new_id, 'date' => date('Y-m-d')));
	    } else {
	        echo json_encode(array('status' => 'error', 'message' => 'Insert failed'));
	    }
	}
}
