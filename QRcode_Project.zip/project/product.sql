/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 100432 (10.4.32-MariaDB)
 Source Host           : 127.0.0.1:3306
 Source Schema         : product

 Target Server Type    : MySQL
 Target Server Version : 100432 (10.4.32-MariaDB)
 File Encoding         : 65001

 Date: 22/09/2024 06:34:41
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for category1
-- ----------------------------
DROP TABLE IF EXISTS `category1`;
CREATE TABLE `category1`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of category1
-- ----------------------------
INSERT INTO `category1` VALUES (1, 'Food');
INSERT INTO `category1` VALUES (2, 'Accessory');

-- ----------------------------
-- Table structure for category2
-- ----------------------------
DROP TABLE IF EXISTS `category2`;
CREATE TABLE `category2`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT ' ',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `parent` int NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of category2
-- ----------------------------
INSERT INTO `category2` VALUES (1, 'Drink', 1);
INSERT INTO `category2` VALUES (2, 'Fast Food', 1);
INSERT INTO `category2` VALUES (3, 'For Bag', 2);
INSERT INTO `category2` VALUES (4, 'Fot cloths', 2);

-- ----------------------------
-- Table structure for product_in
-- ----------------------------
DROP TABLE IF EXISTS `product_in`;
CREATE TABLE `product_in`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `parent` int NULL DEFAULT NULL,
  `amount` int NULL DEFAULT NULL,
  `price` int NULL DEFAULT NULL,
  `in_date` int NULL DEFAULT current_timestamp,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 63 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of product_in
-- ----------------------------
INSERT INTO `product_in` VALUES (1, 'asdfasdf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (2, 'asdfasdf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (3, 'asdfadsf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (4, 'asdfasdf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (5, 'sdfg', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (6, 'asdfasdf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (7, 'asdfasdf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (8, 'asdfasdf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (9, 'asdfasdf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (10, 'dfgsdfg', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (11, 'dfgsdfg', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (12, 'dfgsdfg', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (13, 'dfgsdfgdsf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (14, 'asdfasdf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (15, 'asdfasdf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (16, 'asdfasdf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (17, 'asdfasdf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (18, 'adsfasdf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (19, 'asdfasdf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (20, 'asdfasdf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (21, 'asdfasdf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (22, 'asdfasdf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (23, 'asdfasdf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (24, 'fkjhgf,jhg', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (25, 'asdfasdfasdf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (26, 'asdfasdfasdf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (27, 'sdfgsdfgsdfg', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (28, 'asdfasdfasdf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (29, 'asdfasdf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (30, 'asdfasdf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (31, 'asdfasdf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (32, 'asdfasdf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (33, 'asdfasdf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (34, 'ghjkghjk', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (35, 'ghjkghjk', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (36, 'ghjkghjk', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (37, 'ghjkghjk', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (38, 'ghjkghjk', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (39, 'ghjkghjk', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (40, 'ghjkghjk', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (41, 'ghjkghjk', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (42, 'ghjkghjk', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (43, 'ghjkghjk', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (44, 'ghjkghjk', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (45, 'asdfasdf', 0, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (46, 'asdfasdf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (47, 'asdfasdf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (48, 'asdfasdfsdfsdf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (49, 'asdfasdfasdf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (50, 'asdfasdf', 1, 0, NULL, 2147483647);
INSERT INTO `product_in` VALUES (51, 'asdfasdf', 1, 0, 100000, 2147483647);
INSERT INTO `product_in` VALUES (52, 'qwerqwer', 1, 0, 0, 2147483647);
INSERT INTO `product_in` VALUES (53, 'asdfasdf', 1, 0, 200, 2147483647);
INSERT INTO `product_in` VALUES (54, 'asdfasdf', 1, 0, 12000, 2147483647);
INSERT INTO `product_in` VALUES (55, 'asdfasdf', 1, 0, 12000, 2147483647);
INSERT INTO `product_in` VALUES (56, 'fasdfasdf', 1, 0, 10000, 2147483647);
INSERT INTO `product_in` VALUES (57, 'fasdfasdfasdfasdf', 1, 0, 10000, 0);
INSERT INTO `product_in` VALUES (58, 'fasdfasdfasdfasdf', 1, 0, 10000, 0);
INSERT INTO `product_in` VALUES (59, 'fasdfasdfasdfasdf', 1, 0, 10000, 0);
INSERT INTO `product_in` VALUES (60, 'fasdfasdfasdfasdf', 1, 0, 10000, 0);
INSERT INTO `product_in` VALUES (61, 'fasdfasdfasdfasdf', 1, 0, 10000, 0);
INSERT INTO `product_in` VALUES (62, 'fasdfasdfasdfasdf', 1, 0, 10000, 1726971022);

-- ----------------------------
-- Table structure for product_out
-- ----------------------------
DROP TABLE IF EXISTS `product_out`;
CREATE TABLE `product_out`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `out_date` int NULL DEFAULT NULL,
  `product_id` int NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of product_out
-- ----------------------------
INSERT INTO `product_out` VALUES (1, NULL, 56);
INSERT INTO `product_out` VALUES (2, NULL, 56);
INSERT INTO `product_out` VALUES (3, 0, 56);
INSERT INTO `product_out` VALUES (4, 0, 56);
INSERT INTO `product_out` VALUES (5, 0, 56);
INSERT INTO `product_out` VALUES (6, 0, 56);
INSERT INTO `product_out` VALUES (7, 0, 56);
INSERT INTO `product_out` VALUES (8, 0, 56);
INSERT INTO `product_out` VALUES (9, 0, 56);
INSERT INTO `product_out` VALUES (10, 0, 56);
INSERT INTO `product_out` VALUES (11, 1726971153, 56);
INSERT INTO `product_out` VALUES (12, 1726971153, 56);

SET FOREIGN_KEY_CHECKS = 1;
