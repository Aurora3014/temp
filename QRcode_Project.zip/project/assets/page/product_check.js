$(document).ready(function() {
	var datatableInstance = $('#datatable').DataTable({
		paging: true,
		searching: true,
		info: true,
		ajax: base_url + 'index.php/productcheck/remain_product',
		columnDefs: [
			{ "width": "20%", "targets": 0 }, 
			{ "width": "30%", "targets": 1 },  
			{ "width": "30%", "targets": 2 },
			{ "width": "30%", "targets": 2 },
		]
	});

	$('#datatable tbody').on('click', '#delete', function(){
		datatableInstance.row($(this).parents('tr')).remove().draw();
		totalPrice = datatableInstance.column(1).data().reduce(function(sum, value) {
			return sum + parseFloat(value);  // Convert string to float and sum up
		}, 0);
		$('#total_price').text(totalPrice);

	})
});