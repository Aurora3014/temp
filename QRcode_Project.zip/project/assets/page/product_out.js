var totalPrice = 0

$(document).ready(function() {
	var datatableInstance = $('#datatable').DataTable({
		paging: false,
		searching: false,
		info: false,
		columnDefs: [
			{ "width": "40%", "targets": 0 }, 
			{ "width": "40%", "targets": 1 },  
			{ "width": "20%", "targets": 2 },
		],
		columns: [
            { title: 'Name' },
            { title: 'Price'},
            { title: 'Action' },
            { title: 'Id', visible: false } // Hidden field
        ]
	});

	$('#datatable tbody').on('click', '#delete', function(){
		datatableInstance.row($(this).parents('tr')).remove().draw();
		totalPrice = datatableInstance.column(1).data().reduce(function(sum, value) {
			return sum + parseFloat(value);  // Convert string to float and sum up
		}, 0);
		$('#total_price').text(totalPrice);

	})

	var resultContainer = document.getElementById('qr-results');
	var lastResult, countResults = 0;

	function onScanSuccess(decodedText, decodedResult) {
		if (decodedText !== lastResult) {
			++countResults;
			lastResult = decodedText;
			// Handle on success condition with the decoded message.
			console.log(`Scan result ${decodedText}`, decodedResult);
			$.ajax({
				url: base_url + 'index.php/productout/get_product',  // URL to send the request to
				type: 'GET',                     // HTTP method (GET, POST, etc.)
				data: {id: decodedText},  // Data to send to the server
				success: function(response) {
					// Handle success
					console.log("Response received:", JSON.parse(response));
					dataRes = JSON.parse(response)[0];

					datatableInstance.row.add([
						dataRes.name,
						dataRes.price,
						'<a id="delete"  style="color: red" href="#"><i class="fa fa-times"></i></a>',
						dataRes.id
					]).draw(false);
					

					const totalPrice = datatableInstance.column(1).data().reduce(function(sum, value) {
						return sum + parseFloat(value);  // Convert string to float and sum up
					}, 0); 
					$('#total_price').text(totalPrice);

					setTimeout(function(){
						lastResult = ''
					},2000)
				},
				error: function(jqXHR, textStatus, errorThrown) {
					// Handle error
					console.error("Request failed:", textStatus, errorThrown);
				}
			});
		}
	}

	var html5QrcodeScanner = new Html5QrcodeScanner(
		"qrcode", { fps: 10, qrbox: 480 });
	html5QrcodeScanner.render(onScanSuccess);

	$('#checkout').on('click', function(e){
		if( datatableInstance.rows().count() == 0){
			toastr.error('Your Cart is empty')
			return;
		}
		var uploadData = [];
		datatableInstance.rows().every(function(rowIdx, tableLoop, rowLoop) {
			var rowData = this.data();  // Get data for the current row
			uploadData.push(rowData[3]);
		});
		$.ajax({
			url: base_url + 'index.php/productout/out_product',  // URL to send the request to
			type: 'POST',                     // HTTP method (GET, POST, etc.)
			data: {out: uploadData},  // Data to send to the server
			success: function(response) {
				// Handle success
				console.log("Checkout Completed", JSON.parse(response));				
				datatableInstance.clear().draw();
				$('#total_price').text(0);
			},
			error: function(jqXHR, textStatus, errorThrown) {
				// Handle error
				console.error("Request failed:", textStatus, errorThrown);
			}
		});
	})
});