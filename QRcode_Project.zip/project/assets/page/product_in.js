$(document).ready(function() {

    $('.js-category-1').select2();
    $('.js-category-2').select2();

	$.ajax({
	    url: base_url + 'index.php/productin/get_category_1',  // URL to send the request to
	    type: 'GET',                     // HTTP method (GET, POST, etc.)
	    data: {},  // Data to send to the server
	    success: function(response) {
	        // Handle success
	        console.log("Response received:", JSON.parse(response));
	        $('.js-category-1').empty();
			$.each(JSON.parse(response), function(index, category) {
				var newOption = new Option(category.name, category.id, false, false);
			    $('.js-category-1').append(newOption).trigger('change');
			});
	    },
	    error: function(jqXHR, textStatus, errorThrown) {
	        // Handle error
	        console.error("Request failed:", textStatus, errorThrown);
	    }
	});

	$('.js-category-1').on('change', function(e){
		var category1_id = $(this).val();
			$.ajax({
		    url: base_url + 'index.php/productin/get_category_2',  // URL to send the request to
		    type: 'GET',                     // HTTP method (GET, POST, etc.)
		    data: {id: category1_id},  // Data to send to the server
		    success: function(response) {
		        // Handle success
		        console.log("Response received:", JSON.parse(response));
				$('.js-category-2').empty();
				$.each(JSON.parse(response), function(index, category) {
					var newOption = new Option(category.name, category.id, false, false);
				    $('.js-category-2').append(newOption).trigger('change');
				});
		    },
		    error: function(jqXHR, textStatus, errorThrown) {
		        // Handle error
		        console.error("Request failed:", textStatus, errorThrown);
		    }
		});
	})

	$('#submit').on('click', function(e){
		if($('#name').val() == '' || $('#amount').val() == '0'){
			toastr.info('Warning'); 
			return;
		}
		$.ajax({
		    url: base_url + 'index.php/productin/product_in',  // URL to send the request to
		    type: 'POST',                     // HTTP method (GET, POST, etc.)
		    data: {
		    	parent: $('.js-category-1').val(),
		    	name: $('#name').val(),
		    	amount: $('#amount').val(),
		    	price: $('#price').val(),
		    },  // Data to send to the server
		    success: function(response) {
		        // Handle success
		        receiveddata = JSON.parse(response);
		        console.log("Response received:", receiveddata);
		        $('#qrcode').empty();
		        var qrcode = new QRCode(document.getElementById("qrcode"), {
				  text: receiveddata.id.toString(), // Text or URL for the QR code
				  width: 300, // Width of the QR code
				  height: 300, // Height of the QR code
				});
				setTimeout(function() {
			        // Create a temporary anchor element
			        var link = document.createElement('a');
			        // Set the href and download attributes
			        link.href = $('[data-xblocker="passed"]').attr('src');
			        link.download = $('#name').val() + '_' + receiveddata.date + '.jpg'; // Specify the file name
			        
			        // Append the link to the document body
			        document.body.appendChild(link);
			        
			        // Programmatically click the link to trigger the download
			        link.click();
			        
			        // Remove the link from the document
			        document.body.removeChild(link);
			    }, 2000); // 2000 milliseconds = 2 seconds

		    },
		    error: function(jqXHR, textStatus, errorThrown) {
		        // Handle error
		        console.error("Request failed:", textStatus, errorThrown);
		    }
		});

	})

});